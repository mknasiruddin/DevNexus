# DevNexus – Comprehensive QA & Testing Checklist

**Command to Run Full Automated Verification Suite:**
```bash
npm test
```

---

## 1. Navigation & Page Connectivity (`scripts/test_navigation.js`)
- [x] `GET /` renders Landing Page (`200 OK`) with valid featured project links and `/signup` CTA.
- [x] `GET /projects` renders Project Discovery page (`200 OK`) with filter controls and repository cards.
- [x] `GET /projects/:owner/:repo` validates parameters and redirects (`302`) to `https://github.com/:owner/:repo`.
- [x] `GET /issues` redirects (`302`) to `/projects?topic=good-first-issue`.
- [x] `GET /topics` redirects (`302`) to `/projects`.
- [x] `GET /search?q=react` redirects (`302`) to `/projects?q=react`.
- [x] `GET /learn`, `/learn/git-basics`, and `/learn/code-of-conduct` render the Contribution Guide (`200 OK`).
- [x] `GET /leaderboard` renders the Community Contributor Leaderboard (`200 OK`).
- [x] `GET /maintainers`, `/events`, `/docs`, `/about`, `/privacy`, `/terms` render their respective info pages (`200 OK`).
- [x] `GET /login` and `GET /signup` render the unified Authentication Gateway (`200 OK`).
- [x] Unauthenticated `GET /dashboard`, `GET /onboarding`, and `GET /profile` redirect (`302`) to `/login`.
- [x] Unauthenticated `GET /admin` renders the HTTP `403` Administrator Gateway (`views/admin-forbidden.ejs`).
- [x] Non-existent routes (`GET /non-existent-route`) return HTTP `404` (`Page Not Found` HTML or `{ success: false }` JSON).
- [x] Navbar `#theme-toggle`, `#burger` mobile menu, and `/` keyboard search focus work across all pages.

---

## 2. Forms & Input Validation (`scripts/test_auth.js` & `scripts/run_all_tests.js`)
- [x] **Registration (`POST /auth/signup` & `POST /signup`):**
  - [x] Rejects missing username, email, or password.
  - [x] Rejects invalid email formats (`/^[^\s@]+@[^\s@]+\.[^\s@]+$/`).
  - [x] Rejects usernames shorter than 3 characters or containing invalid characters (`[a-zA-Z0-9_-]{3,39}`).
  - [x] Rejects passwords shorter than 6 characters or mismatched `confirmPassword`.
  - [x] Rejects duplicate usernames or emails with a clear error banner.
- [x] **Login (`POST /auth/login` & `POST /login`):**
  - [x] Authenticates valid username or email + password.
  - [x] Rejects invalid credentials and increments rate-limiter counter.
- [x] **Developer Onboarding & Profile Editing (`POST /onboarding` & `POST /profile`):**
  - [x] Validates `experience_level` against `['Beginner', 'Intermediate', 'Advanced']`.
  - [x] Persists `name`, `bio`, `experience_level`, and `skills` JSON array in SQLite.
- [x] **Project & Issue Search (`GET /projects`, `GET /dashboard`):**
  - [x] Safely handles empty queries, special characters, and zero-result states.
  - [x] Clamps `page` and `perPage` parameters to safe bounds.

---

## 3. Authentication & Security (`scripts/test_admin_security.js` & `scripts/test_github_oauth.js`)
- [x] Passwords hashed using `bcrypt` (cost factor 12); zero plaintext passwords stored in SQLite.
- [x] Legacy `scrypt` password hashes transparently upgraded to `bcrypt` upon successful sign-in.
- [x] Session IDs regenerated (`req.session.regenerate()`) upon login, signup, OAuth callback, demo login, and admin login.
- [x] Session cookies set with `HttpOnly` and `SameSite=Lax` (`Secure` enabled in production).
- [x] Demo login (`POST /auth/demo-login`) blocks impersonation of `admin`, `maintainer`, password-protected, OAuth-linked, or suspended accounts.
- [x] Login rate limiting blocks brute-force attacks after 15 failed attempts per 15-minute window.
- [x] GitHub OAuth (`/auth/github` & `/auth/github/callback`) validates cryptographic `state` parameter against CSRF and gracefully handles `error=access_denied`.
- [x] Security headers (`X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: strict-origin-when-cross-origin`) present on all responses; `X-Powered-By` disabled.
- [x] Suspended accounts are immediately blocked from accessing protected routes or signing in.
- [x] Primary administrator cannot demote or suspend their own account.

---

## 4. Database Connectivity & Persistence (`db/database.js`)
- [x] SQLite database (`data/devnexus.sqlite`) runs with `PRAGMA journal_mode = WAL` and `PRAGMA foreign_keys = ON`.
- [x] User registration, login, onboarding, and profile updates persist across server restarts.
- [x] Bookmark creation (`POST /dashboard/api/bookmarks`) and removal (`DELETE /dashboard/api/bookmarks`) persist in the `bookmarks` table and enforce user ownership (`user_id`).
- [x] Leaderboard contributor profiles and activities persist in `contributors` and `contributor_activities` with unique `event_id` deduplication.
- [x] Admin role updates and account status toggles persist in `users` and record audit entries in `activity_logs`.
- [x] `.env` and `data/*.sqlite*` runtime files are excluded via `.gitignore`.

---

## 5. GitHub API Integration (`scripts/test_projects.js` & `scripts/test_leaderboard.js`)
- [x] Live repository discovery (`searchRepositories`) filters by keyword, language, topic, stars, and sort order.
- [x] Live issue discovery (`searchIssues`) filters by `good first issue`, `help wanted`, language, and keyword, and computes rule-based compatibility scores.
- [x] Developer dashboard profile inspection (`GET /dashboard?username=...`) fetches live GitHub user profile, repositories, and public events.
- [x] Network errors, invalid tokens (`401` retry fallback), and rate-limit responses (`403`) are caught and displayed gracefully without crashing the server.
