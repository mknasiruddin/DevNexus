# DevNexus – Complete Application Audit, Bug Fixing & Functionality Improvement Report

**Project:** DevNexus – Open-Source Contribution and Collaboration Platform  
**Branch Audited:** `saanvi-login` (preserved without branch switching or destructive Git operations)  
**Audit Date:** November 2026  

---

## 1. Project Overview

**DevNexus** is a server-rendered open-source contribution and collaboration web application designed to help student developers and first-time open-source contributors discover beginner-friendly repositories (`good first issue`, `help wanted`), evaluate algorithmic skill compatibility, bookmark issues persistently, track public GitHub contribution velocity on a community leaderboard, and manage platform users through an administrative dashboard.

The application follows a modular Model-View-Controller / Service-oriented Express architecture:
- **Entry Point:** [`app.js`](file:///c:/Users/HP/Documents/DevNexus/app.js)
- **Database Layer:** [`db/database.js`](file:///c:/Users/HP/Documents/DevNexus/db/database.js) (`node:sqlite` `DatabaseSync` with WAL mode and foreign key constraints)
- **Models:** [`models/User.js`](file:///c:/Users/HP/Documents/DevNexus/models/User.js), [`models/Contributor.js`](file:///c:/Users/HP/Documents/DevNexus/models/Contributor.js)
- **Services:** [`services/authService.js`](file:///c:/Users/HP/Documents/DevNexus/services/authService.js), [`services/githubService.js`](file:///c:/Users/HP/Documents/DevNexus/services/githubService.js)
- **Routes:** [`routes/authRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/authRoutes.js), [`routes/dashboardRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/dashboardRoutes.js), [`routes/projectRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/projectRoutes.js), [`routes/contentRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/contentRoutes.js), [`routes/adminRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/adminRoutes.js)
- **Views:** [`views/`](file:///c:/Users/HP/Documents/DevNexus/views) (EJS templates & reusable partials)
- **Static Assets:** [`public/css/`](file:///c:/Users/HP/Documents/DevNexus/public/css), [`public/js/`](file:///c:/Users/HP/Documents/DevNexus/public/js)
- **Automated Verification Suites:** [`scripts/`](file:///c:/Users/HP/Documents/DevNexus/scripts)

---

## 2. Confirmed Technology Stack

| Layer | Technology | Implementation Details |
| :--- | :--- | :--- |
| **Runtime** | Node.js (v22+) | Uses native `fetch`, `crypto`, and built-in `node:sqlite` |
| **Web Framework** | Express.js (`^5.2.1`) | Server routing, middleware pipeline, JSON & URL-encoded body parsing |
| **Templating Engine** | EJS (`^6.0.1`) | Server-side HTML rendering with dark/light theme support |
| **Database** | SQLite (`node:sqlite`) | Persistent file storage at `data/devnexus.sqlite` in `WAL` journal mode |
| **Password Security** | `bcryptjs` (`^3.0.3`) & `crypto.scryptSync` | `bcrypt` cost factor 12 with transparent upgrade from legacy `scrypt` hashes |
| **External API** | GitHub REST API v3 | OAuth 2.0 flow, repository search, issue search, user profiles, public events |
| **Frontend** | HTML5, CSS3, Vanilla JS | Responsive layout, custom CSS variables, accessible keyboard shortcuts |

> **Architecture Alignment Note:** If any external SRS document references React or MongoDB/MERN, the actual implemented and verified architecture of DevNexus is **Node.js + Express 5 + EJS + SQLite + GitHub REST API v3**. Per project rules, this stack has been strictly preserved without introducing React, MongoDB, or AI dependencies.

---

## 3. Existing Features Identified

### Completed & Working Core Modules
1. **Landing Page ([`views/landing.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/landing.ejs))**: Hero section, interactive issue preview filter, contribution heatmap, 3-step terminal walkthrough, featured open-source projects, and navigation.
2. **User Authentication & Authorization ([`routes/authRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/authRoutes.js), [`services/authService.js`](file:///c:/Users/HP/Documents/DevNexus/services/authService.js))**:
   - Local registration and login with `bcrypt` password hashing.
   - GitHub OAuth 2.0 login (`/auth/github` & `/auth/github/callback`) with cryptographic `state` validation and setup guide fallback when credentials are not configured.
   - Server-side SQLite session persistence (`sessions` table) with `HttpOnly; SameSite=Lax` cookies.
   - Role-based access control (`contributor`, `maintainer`, `admin`) and account suspension enforcement.
3. **Developer Onboarding & Profile ([`views/onboarding.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/onboarding.ejs))**: Experience level (`Beginner`, `Intermediate`, `Advanced`), display name, bio, and technical skill selection persisted in SQLite.
4. **Project Discovery ([`routes/projectRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/projectRoutes.js), [`views/projects.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/projects.ejs))**: Live GitHub repository search with keyword, programming language, topic, minimum stars, and sort order filters, plus 5-minute SQLite API caching.
5. **Developer Dashboard & Issue Discovery ([`routes/dashboardRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/dashboardRoutes.js), [`views/dashboard.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/dashboard.ejs))**:
   - Live GitHub profile, repository list, and public activity feed.
   - Live open-source issue search with `good first issue` and `help wanted` label tabs, language filter, pagination, and algorithmic skill-compatibility scoring (`calculateCompatibility`).
6. **Persistent Bookmarking ([`db/database.js`](file:///c:/Users/HP/Documents/DevNexus/db/database.js), [`public/js/dashboard.js`](file:///c:/Users/HP/Documents/DevNexus/public/js/dashboard.js))**: Add/remove issue bookmarks stored in the SQLite `bookmarks` table per user.
7. **Community Contributor Leaderboard ([`views/leaderboard.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/leaderboard.ejs), [`routes/contentRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/contentRoutes.js))**: Transparent rule-based scoring rubric (`Merged PR: +12`, `Opened PR: +10`, `Issue: +5`, `Commit Push: +4..8`, `Review: +3`, `Bookmark: +1`), podium cards, category tabs (`Top`, `Most Active`, `Rising`), time filters (`All-Time`, `This Month`, `This Week`), and live GitHub handle indexing (`POST /leaderboard/sync`).
8. **Contribution Guide & Info Pages ([`views/guide.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/guide.ejs), [`views/info.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/info.ejs))**: Step-by-step Git/PR tutorial, Git basics, Code of Conduct, Maintainers guide, Docs, About, Privacy, and Terms pages.
9. **Admin Dashboard ([`routes/adminRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/adminRoutes.js), [`views/admin.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/admin.ejs))**: Protected administrative portal with live Node.js process metrics, user role management, account suspension/activation, bookmark analytics, and audit activity logs.

---

## 4. Bugs Discovered & Fixed

| # | Location | Bug Description | Fix Implemented |
| :- | :--- | :--- | :--- |
| 1 | [`db/database.js`](file:///c:/Users/HP/Documents/DevNexus/db/database.js) & [`routes/authRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/authRoutes.js) | **Critical Privilege Escalation in Demo Login:** `POST /auth/demo-login` called `findOrCreateDemoUser(username)`, which returned *any* existing user matching `username` (including `admin` or password-protected users) and created an authenticated session without a password. | Restricted `findOrCreateDemoUser` and `/auth/demo-login` to reject any account that has `role !== 'contributor'`, has a `password_hash` or `github_id`, or is `suspended`, and blocked the request before making any GitHub API call. |
| 2 | [`views/partials/dashboard-nav.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/partials/dashboard-nav.ejs) | **Broken Theme Toggle & Mobile Menu on 9 Pages:** `#theme-toggle`, `#burger`, and `/` search focus only had event listeners in `dashboard.js` and `admin.js`, leaving the navbar buttons unresponsive on `/projects`, `/leaderboard`, `/learn`, `/login`, `/onboarding`, `/docs`, `/error`, and `/admin/login`. | Added an idempotent navbar script (`window.__devnexusNavInit`) inside `dashboard-nav.ejs` and guarded `dashboard.js`/`admin.js` against duplicate binding. |
| 3 | [`routes/dashboardRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/dashboardRoutes.js) | **Dashboard "Inspect" Form Ignored `?username=`:** Both the dashboard sidebar form and project cards submit `GET /dashboard?username=<login>`, but `dashboardRoutes.js` hardcoded `const targetUsername = req.user.username;`. | Updated `dashboardRoutes.js` to validate and use `req.query.username` (`targetUsername`) while preserving `req.user` for authentication, skill matching, and bookmarks. |
| 4 | [`views/dashboard.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/dashboard.ejs) | **Hardcoded Sidebar Skills & Experience Level:** The dashboard sidebar hardcoded `JavaScript, Python, TypeScript, Rust, Go` and `Authenticated User` instead of rendering the user's saved `user.skills`, `user.experience_level`, `user.name`, and `user.bio` from SQLite, and had no link to edit profile preferences after onboarding. | Rendered dynamic `userSkills`, `user.experience_level`, `user.name`, and `user.bio` in `dashboard.ejs`, added an **Edit Profile & Skills** button (`/onboarding?edit=1` / `/profile`), and added a `POST /profile` endpoint. |
| 5 | [`views/dashboard.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/dashboard.ejs) & [`public/js/dashboard.js`](file:///c:/Users/HP/Documents/DevNexus/public/js/dashboard.js) | **No Remove Button in Saved Bookmarks Tab:** Users viewing their saved bookmarks in `#bookmarks-view-container` could not remove a bookmarked issue from that list. | Added a **Remove** button (`.remove-saved-bookmark-btn`) to each saved bookmark row and wired `DELETE /dashboard/api/bookmarks` in `dashboard.js` to remove the row and sync all badge counters. |
| 6 | [`db/database.js`](file:///c:/Users/HP/Documents/DevNexus/db/database.js) | **SQL String Interpolation & NULL Velocity in `getLeaderboard`:** `getLeaderboard` interpolated ISO date strings directly into SQL and subtracted two `SUM(points)` subqueries without `COALESCE`, which yielded `NULL` velocity whenever a contributor had no events in one of the 7-day windows. | Parameterized all date bindings with `?` placeholders and wrapped both velocity subqueries in `COALESCE(..., 0)`. |
| 7 | [`services/githubService.js`](file:///c:/Users/HP/Documents/DevNexus/services/githubService.js) | **Uncaught Network Exceptions & Expired Token Failures:** `fetch()` calls in `getUserProfile`, `getUserRepositories`, `getUserEvents`, `searchIssues`, and `searchRepositories` were not wrapped in `try/catch` and did not retry unauthenticated if an environment `GITHUB_TOKEN` returned `401`. | Created `safeGithubFetch(url, token)` to catch network/DNS errors cleanly and automatically retry unauthenticated on HTTP `401`. |
| 8 | [`routes/adminRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/adminRoutes.js) | **Missing User Existence Checks in Admin API:** `POST /admin/users/:id/role` and `POST /admin/users/:id/toggle-status` did not check if `:id` existed in SQLite before returning `{ success: true }`. | Added `findUserById(targetUserId)` validation and returned HTTP `404` JSON if the user does not exist. |
| 9 | [`views/login.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/login.ejs) & [`routes/authRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/authRoutes.js) | **Form Action Mismatch & Misleading Password Reset Text:** `login.ejs` used `action="/login"` and `action="/signup"` instead of `/auth/login` and `/auth/signup`, and the forgot-password form said "Send Reset" even though no email server is configured. | Updated form actions to `/auth/login` and `/auth/signup`, added backend/frontend email and username validation, and updated Password Assistance to clearly state automated email reset is disabled and requests are logged in `activity_logs` for administrator review. |
| 10 | [`views/landing.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/landing.ejs) | **Fictional Repository Links on Landing Page:** Featured project cards (`lumen-ui/lumen`, `tabular-py/tabular`, etc.) linked to `/projects/:owner/:repo`, which redirected users to 404 pages on GitHub. Also, the `Get started` CTA for logged-out users pointed to `/login` instead of `/signup`. | Replaced featured repositories with real open-source projects (`facebook/react`, `pandas-dev/pandas`, `golang/go`, `rust-lang/rust`, `nodejs/node`, `microsoft/TypeScript`), badged the hero widget as an interactive preview, and pointed `routes.signup` to `/signup`. |
| 11 | [`app.js`](file:///c:/Users/HP/Documents/DevNexus/app.js) | **Missing 404 & Global Error Middleware:** Unmatched routes returned default Express plain-text `Cannot GET ...` responses. | Added a structured 404 Not Found handler (rendering `views/error.ejs` or JSON) and a global 500 error handler that never leaks stack traces. |

---

## 5. Security Issues Found and Fixed

1. **Unauthorized Account Impersonation via Demo Login (Critical):**
   - *Issue:* Any visitor could submit `username=admin` (or any registered user's username) to `POST /auth/demo-login` and gain full access to that account without a password.
   - *Fix:* Hardened both `findOrCreateDemoUser` in [`db/database.js`](file:///c:/Users/HP/Documents/DevNexus/db/database.js) and `/auth/demo-login` in [`routes/authRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/authRoutes.js) to reject any account with `role !== 'contributor'`, any account with a `password_hash` or `github_id`, and any `suspended` account. Disabled demo login in production unless `ALLOW_DEMO_LOGIN=true`.
2. **Session Fixation Protection:**
   - *Issue:* `req.session` was mutated in place upon login without regenerating the session identifier.
   - *Fix:* Implemented `req.session.regenerate()` in [`services/authService.js`](file:///c:/Users/HP/Documents/DevNexus/services/authService.js) (which destroys the pre-login session row in SQLite and issues a fresh 32-byte cryptographic session ID) and invoked it on local login, signup, GitHub OAuth callback, demo login, and admin login.
3. **Brute-Force Login Rate Limiting:**
   - *Issue:* Login endpoints (`/login`, `/auth/login`, `/admin/login`) had no rate limiting against automated password guessing.
   - *Fix:* Added `loginRateLimiter`, `recordFailedLoginAttempt`, and `clearLoginAttempts` in [`services/authService.js`](file:///c:/Users/HP/Documents/DevNexus/services/authService.js) (limiting to 15 failed attempts per 15-minute window per IP).
4. **HTTP Security Headers & Fingerprinting:**
   - *Issue:* Responses lacked security headers and exposed `X-Powered-By: Express`.
   - *Fix:* Disabled `x-powered-by` in [`app.js`](file:///c:/Users/HP/Documents/DevNexus/app.js) and added `securityHeadersMiddleware` setting `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: strict-origin-when-cross-origin`, and `X-XSS-Protection: 0`.
5. **SQL Parameterization:**
   - *Issue:* `getLeaderboard` in [`db/database.js`](file:///c:/Users/HP/Documents/DevNexus/db/database.js) used template string interpolation for date cutoffs.
   - *Fix:* Replaced all interpolated date strings in SQL queries with parameterized `?` bindings.

---

## 6. UI/UX Improvements Made

- **Universal Theme Switcher & Mobile Menu:** Fixed `#theme-toggle` (dark/light mode with `localStorage` persistence), `#burger` mobile drawer (`aria-expanded` toggle), and `/` keyboard search shortcut across all 12 views via [`views/partials/dashboard-nav.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/partials/dashboard-nav.ejs).
- **Developer Profile & Skill Customization Flow:** Added `/profile` and `/onboarding?edit=1` so authenticated developers can update their display name, bio, experience level (`Beginner`, `Intermediate`, `Advanced`), and skill tags at any time, with immediate reflection on the Developer Dashboard sidebar and issue compatibility scores.
- **Saved Bookmarks Management:** Added a direct **Remove** button on every bookmarked issue inside the Dashboard's "Saved Bookmarks" view with instant DOM and badge count synchronization.
- **Inspect Any GitHub Developer on Dashboard:** Enabled the sidebar "Inspect GitHub Handle" form (`GET /dashboard?username=...`) with a quick "Reset to @user" link when inspecting another contributor.
- **Clear Status & Disclosure Banners:** Added profile-update confirmation banners, transparent password assistance messaging, and accurate interactive preview labels on the landing page.

---

## 7. Backend and Database Fixes

- **SQLite Schema & Persistence (`data/devnexus.sqlite`):**
  - Verified all 6 tables (`users`, `sessions`, `bookmarks`, `activity_logs`, `api_cache`, `contributors`, `contributor_activities`), foreign key cascades (`ON DELETE CASCADE`), and unique indexes (`idx_bookmarks_user_url`, `idx_contributors_username`, `idx_contrib_act_event_id`).
  - Preserved all existing real user accounts (`admin`, `saanvirao`, `Saanvi-P-Rao`, `surabhi`) and purged leftover temporary test records (`user_177...`, `test_dev_leaderboard`).
  - Added periodic expired session cleanup (`cleanExpiredSessions`) in [`services/authService.js`](file:///c:/Users/HP/Documents/DevNexus/services/authService.js).
- **Input Validation:**
  - Enforced server-side email regex validation, username length (3–39 alphanumeric/hyphen/underscore characters), password minimum length (6+ characters), password confirmation matching, and experience level enum validation (`Beginner`, `Intermediate`, `Advanced`).

---

## 8. GitHub API Integration Validation

- Verified all endpoints in [`services/githubService.js`](file:///c:/Users/HP/Documents/DevNexus/services/githubService.js):
  - `getOAuthAuthorizeUrl`, `exchangeOAuthCode`, `getAuthenticatedUser`
  - `getUserProfile`, `getUserRepositories`, `getUserEvents`
  - `searchIssues` (with `good first issue`, `help wanted`, language filter, pagination clamping, and rule-based compatibility scoring)
  - `searchRepositories` (with keyword, language, topic, minimum stars, and sort order)
  - `syncContributorFromGitHub` (indexing real public GitHub events into `contributors` and `contributor_activities`)
- Verified rate-limit header extraction (`parseRateLimit`), 5–10 minute SQLite caching (`api_cache`), unauthenticated retry on `401`, and graceful fallback when rate-limited (`403`) or offline (`NETWORK_ERROR`).

---

## 9. Modified & Added Files

| File Path | Summary of Changes |
| :--- | :--- |
| [`app.js`](file:///c:/Users/HP/Documents/DevNexus/app.js) | Added security headers middleware, `/profile` routes, 404 Not Found handler, and global 500 error middleware. |
| [`package.json`](file:///c:/Users/HP/Documents/DevNexus/package.json) | Fixed `"main": "app.js"`, added `"dev"` script, and configured `"test": "node scripts/run_all_tests.js"`. |
| [`db/database.js`](file:///c:/Users/HP/Documents/DevNexus/db/database.js) | Hardened `findOrCreateDemoUser`, added email/username validation in `registerLocalUser`, expanded `updateUserProfile`, and parameterized `getLeaderboard` SQL with `COALESCE`. |
| [`services/authService.js`](file:///c:/Users/HP/Documents/DevNexus/services/authService.js) | Added `req.session.regenerate()`, `securityHeadersMiddleware`, `loginRateLimiter`, and periodic expired session cleanup. |
| [`services/githubService.js`](file:///c:/Users/HP/Documents/DevNexus/services/githubService.js) | Added `safeGithubFetch` with network error catching and 401 token fallback, plus pagination bounds clamping. |
| [`routes/authRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/authRoutes.js) | Integrated session regeneration, login rate limiting, demo-login impersonation blocking, profile editing handler (`handlePostProfile`), and transparent password assistance logging. |
| [`routes/dashboardRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/dashboardRoutes.js) | Supported `?username=` inspection, passed parsed `userSkills` and `profileUpdated`, and mounted `POST /dashboard/profile`. |
| [`routes/adminRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/adminRoutes.js) | Validated target user existence (`findUserById`) before role updates or status toggles. |
| [`routes/projectRoutes.js`](file:///c:/Users/HP/Documents/DevNexus/routes/projectRoutes.js) | Validated `:owner` and `:repo` parameters in `GET /projects/:owner/:repo`. |
| [`views/partials/dashboard-nav.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/partials/dashboard-nav.ejs) | Added universal theme toggle, mobile menu, and `/` search shortcut script; linked profile pill to `/profile`. |
| [`views/dashboard.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/dashboard.ejs) | Rendered real user skills, experience level, bio, profile edit link, inspect reset link, and bookmark remove button. |
| [`views/login.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/login.ejs) | Updated form actions to `/auth/login` and `/auth/signup`, added input constraints, and clarified password assistance and demo sandbox notices. |
| [`views/onboarding.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/onboarding.ejs) | Added support for editing existing profile (`name`, `bio`, `experience_level`, `skills`). |
| [`views/landing.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/landing.ejs) | Replaced fictional repo links with real open-source repositories, fixed `/signup` CTA route, and labeled preview widget. |
| [`views/info.ejs`](file:///c:/Users/HP/Documents/DevNexus/views/info.ejs) | Guarded `locals.leaderboard` and updated authentication documentation to reflect `bcrypt`. |
| [`public/js/dashboard.js`](file:///c:/Users/HP/Documents/DevNexus/public/js/dashboard.js) | Added `.remove-saved-bookmark-btn` handler and guarded navbar listeners against duplicate binding. |
| [`public/js/admin.js`](file:///c:/Users/HP/Documents/DevNexus/public/js/admin.js) | Guarded navbar listeners against duplicate binding. |
| [`scripts/test_auth.js`](file:///c:/Users/HP/Documents/DevNexus/scripts/test_auth.js) | Added automatic cleanup of temporary test user rows in `finally`. |
| [`scripts/test_leaderboard.js`](file:///c:/Users/HP/Documents/DevNexus/scripts/test_leaderboard.js) | Added automatic cleanup of temporary test contributor rows in `finally`. |
| [`scripts/run_all_tests.js`](file:///c:/Users/HP/Documents/DevNexus/scripts/run_all_tests.js) | Created master QA test runner executing all 6 test suites plus 8 extended security, profile, bookmark, and 404 audit checks. |

---

## 10. Testing Results

All 7 automated verification suites (`npm test` / `node scripts/run_all_tests.js`) passed with **0 failures**:
1. **`scripts/test_navigation.js`**: 26/26 route, redirect, auth guard, and navbar link checks passed.
2. **`scripts/test_auth.js`**: 16/16 registration, login, onboarding, logout, and form placeholder checks passed.
3. **`scripts/test_github_oauth.js`**: 10/10 OAuth configuration, state CSRF protection, callback error handling, and dynamic callback URL checks passed.
4. **`scripts/test_projects.js`**: 6/6 live GitHub repository discovery, language/star filtering, JSON API, and caching checks passed.
5. **`scripts/test_leaderboard.js`**: 6/6 contributor upsert, event deduplication, category ranking, time window filtering, and sync validation checks passed.
6. **`scripts/test_admin_security.js`**: 15/15 `bcrypt` hashing, legacy `scrypt` upgrade, RBAC enforcement, admin self-demotion protection, and account suspension checks passed.
7. **`scripts/run_all_tests.js` (Extended Audit Suite)**: 8/8 checks passed (HTTP security headers, demo-login privilege escalation prevention, registration email/username validation, profile editing persistence, SQLite bookmark CRUD, password assistance logging, and 404 HTML/JSON handling).

---

## 11. Remaining Recommendations

1. **GitHub Personal Access Token (`GITHUB_TOKEN`) for High-Traffic Demos:** Unauthenticated GitHub Search API requests are limited to 10 requests/minute (and Core API to 60 requests/hour). Adding a read-only `GITHUB_TOKEN` in `.env` increases the quota to 5,000 requests/hour (Core) and 30 requests/minute (Search) while the built-in SQLite `api_cache` table caches responses for 5–10 minutes.
2. **Production HTTPS & `SESSION_SECRET`:** When deploying behind a reverse proxy (Render, Railway, Nginx), set `NODE_ENV=production` and a strong random `SESSION_SECRET` in `.env` so session cookies automatically include the `Secure` flag.
3. **SMTP Integration (Optional Future Enhancement):** If automated password reset emails are desired in future iterations, integrate Nodemailer with time-limited signed reset tokens stored in SQLite.
